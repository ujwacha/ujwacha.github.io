//includes
#include <stdio.h>

//main function
int main(){
	int cha ;
	cha = getchar();
	while (cha != EOF ){
		putchar(cha);
		cha = getchar();

	}

}
