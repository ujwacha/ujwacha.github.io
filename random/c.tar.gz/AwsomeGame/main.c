
/***********

 ____                         __  __ _
/ ___| _ __   __ _  ___ ___  |  \/  (_)_ __   ___ _ __
\___ \| '_ \ / _` |/ __/ _ \ | |\/| | | '_ \ / _ \ '__|
 ___) | |_) | (_| | (_|  __/ | |  | | | | | |  __/ |
|____/| .__/ \__,_|\___\___| |_|  |_|_|_| |_|\___|_|
      |_|


 
This Game is Awesome 
Author - Acharya Ujwol AU
*************/



#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//// Header files for taking input from getchar without Enter
#include <termios.h>
#include <unistd.h>
/////////////////////////////////////////
/*****
Defining global variables and arrays 
******/
char Board[30][30] ;
int LocationX , LocationY ;
int LocationX = 2 ;
int LocationY = 2 ;
int input;
int input;
int turn = 0 ;
int random1 ;
int *random1Point = &random1;
int random2 ;
int *random2Point = &random2; 
int score ;

/// This function initialzes the board 

void Initializer(){
    for(int i = 0 ; i < 30 ; i++){
        for(int j = 0 ; j < 30 ; j++){
            if(i == LocationX && j == LocationY){
                Board[i][j] = '#' ;
            }else if (i== random1 && j == random2){
                
                Board[i][j] = '@' ;
            } else{
                Board[i][j] = ' ' ;
            }
        }

    }

}




///// This funtion makes  the player move around the board with the
///// defined keybindings


void To_Move(int x){
    if(x=='a'){
        LocationY--;
        turn++;
    }else if(x=='d'){
        LocationY++;
        turn++;
    }else if(x=='w'){
        LocationX--;
        turn++;
    }else if(x=='s'){
        LocationX++;
        turn++;
    }else {

    }

}



///// this is the function to add up scores 

void Scorer(){
    if(LocationX == random1 && LocationY == random2){
        score ++ ;
    }

}


// IDK why this is so cool , using the retro terminal



int main(){



}
