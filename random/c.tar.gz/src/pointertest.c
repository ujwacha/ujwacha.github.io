#include <stdio.h>

int main(){
	int a ;
	int *ptr = &a ;
	printf("a = %d \n ptr = %p \n " , a , ptr);
	a = 39 ;
	printf("new value of \n a = %d \n" , a);


}
