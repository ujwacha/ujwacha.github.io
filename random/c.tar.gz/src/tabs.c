#include <stdio.h>
#include <stdlib.h>
int main(){

	long c ;
	int tab ;
	
	c = getchar();
	while(c != EOF){

		if  (c == '\t'){tab++;}
		c  = getchar();

	}
	printf("%i\n",(tab-32766));
	return 0;

}
