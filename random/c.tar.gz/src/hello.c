#include <stdio.h>
int main(){

	printf("hellow world \n\n\");

}
