#include <stdio.h>

void no_return(){
	printf("Nothing is returned");

}

int returner(){

	return 65;

}
int main(){

	returner();
	int ccc = (15 + no_return());

}
