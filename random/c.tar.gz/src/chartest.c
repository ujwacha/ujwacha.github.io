#include <stdio.h>
int main(){

	for(int i = 127 ; i!=EOF ; i--){

		putchar(i);



	}
	putchar('\n');

}
