#include <stdio.h>
int main(){
    int x ;
    printf("How many plates of momos did you eat today ? >> ");
    scanf("%i",&x);
    switch(x){
        case 1 :
            printf("not enough\n");
            break ;
        case 2 :
            printf("counld be better\n");
            break;

        case 3 :
            printf("you are getting close\n");
            break ;
        case 4 :
            printf("wish you ate another plate \n");
            break;
        default :
            printf("Very good \n");


    }
 printf("please eat more momos \n\n\n\n\n");   


}