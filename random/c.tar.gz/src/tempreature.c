//includes
#include <stdio.h>

// F to C
float Cel(int x){


	return ((float) 5/9 * (x-32)) ; // formula
	


}
//main 
int main(){
	printf("%i\t%.3f\n",1,Cel(1)); // the first
	for(int i=1 ; i <=15 ; i++){ // for loop to get through the sequence of the input
		printf("%i\t%.3f\n",(i*20),Cel((i*20))); // prints out the values ;;;;;
	}

	return 0 ;
}
