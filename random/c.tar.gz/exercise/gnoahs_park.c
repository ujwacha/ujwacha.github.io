// global vars 
int num_gnus ;
int num_gnats ;

// new function
void calculate_park_biomass(float avg_gnu_mass ,float avg_gnat_mass){



}


int main(){

float avg_gnu_mass ;
float avg_gnat_mass ;


}
