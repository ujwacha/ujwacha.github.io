#include <stdio.h>

//// this is a plane old function to print a same character a number of times 
void repeater(char ch , int num){
	for (int i = 0 ; i < num ; i++){
		putchar(ch);
	}	
}


int main(){
	int input;
	do {


		printf("input a odd number >> ");
		scanf("%i", &input);

	} while(input % 2 != 1) ; // is is hard coded that the imput must be odd

	int start = 1 ; // it is hard coded so that the function works the way it is supposed to 
	int temp = input / 2 ;


	

	/*****
	here i will explain the for loop below this block of comment
	lets take an example , the input is 5
	then the mountain would have to be :
	  i
	 iii
	iiiii 
	
	here we have first 2 spaces , which is the int value of input/2 = temp
	then the 'i' is added , then the '\n is added'
	then , the number of spaces dicrease by 1 ,
	the number of 'i' s increase by 2
	than again the '\n' is added after one loop
	and this alogrithm must continue untill temp = 0
	and the variable start would have to be increased by 2 in each loop

	this is how the following block will work
	 **********/


	for(int i = temp ; i >= 0 ; i = i - 1){

		repeater(' ', i);
		repeater('*', start);
		putchar('\n');
		start = start + 2 ;
	} 
}
