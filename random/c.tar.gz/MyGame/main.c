/***********

 ____                         __  __ _
/ ___| _ __   __ _  ___ ___  |  \/  (_)_ __   ___ _ __
\___ \| '_ \ / _` |/ __/ _ \ | |\/| | | '_ \ / _ \ '__|
 ___) | |_) | (_| | (_|  __/ | |  | | | | | |  __/ |
|____/| .__/ \__,_|\___\___| |_|  |_|_|_| |_|\___|_|
      |_|


 
This Game is Awesome 
Author - Acharya Ujwol AU
*************/

/// Header Files

#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>
#include <time.h>
////#include<conio.h>



//// Header Files OVER

char Board[30][30] ;
int LocationX , LocationY ;
int LocationX = 2 ;
int LocationY = 2 ;
int input;
int turn = 0 ;
int random1 ;
int random2 ;
int *random2Point = &random2; 
int *random1Point = &random1;

int score ;
/////////////////////////////////////////////////
 ////


void Initializer(){
    for(int i = 0 ; i < 30 ; i++){
        for(int j = 0 ; j < 30 ; j++){
            if(i == LocationX && j == LocationY){
                Board[i][j] = '#' ;
            }else if (i== random1 && j == random2){
                
                Board[i][j] = '@' ;
            } else{
                Board[i][j] = ' ' ;
            }
        }

    }

}


int RandomNumber(){

    srand(time(NULL));  // passing time on the function
    int number = rand(); // returning the time and checking  the remainder by 6
    return number ;
}

void To_Move(int x){
    if(x=='a'){
        LocationY--;
        turn++;
    }else if(x=='d'){
        LocationY++;
        turn++;
    }else if(x=='w'){
        LocationX--;
        turn++;
    }else if(x=='s'){
        LocationX++;
        turn++;
    }else {

    }

}
void BetterOutput(){
    printf("\n\n_________________________________________________\n\n");
        for(int i = 0 ; i < 30 ; i++){
            putchar('|');
            for(int j = 0 ; j < 30 ; j++){
                putchar(Board[i][j]);
                putchar('|'); 

            }
            putchar('\n');
        }

    printf("\n\n__________________________________________________\n\n %i \n\n %i ___________" , turn , score);



}
void Scorer(){
    if(LocationX == random1 && LocationY == random2){
        score ++ ;
    }

}





int main(){

    static struct termios oldt, newt;           // These lines are supposed let the 
    tcgetattr( STDIN_FILENO, &oldt);            // values be entered eithout pressing enter button
    newt = oldt;                                // IDK how this thing works , i copied this from a
    newt.c_lflag &= ~(ICANON);                  // Tutorial PDF
    tcsetattr( STDIN_FILENO, TCSANOW, &newt);   // BUT it works so i won't touch this XDDDD


    /////////////////////////////////////////////////

    ////////////////////////////////////////////////

    while(1) {



        //////////////////////////////////////////
        Initializer();

    

        BetterOutput();
        input = getchar();
        if(input=='l'){
  
            tcsetattr( STDIN_FILENO, TCSANOW, &oldt); // this line is supposed to bring back the default terminal settings
            putchar('\n');
             exit(0);
            }

        To_Move(input);
        Scorer();
        system("clear");

        //////////////////////////////////////////
        int *random1Point = RandomNumber() % 25 ;
        int *random2Point = RandomNumber() % 25 ;
        printf("\n\n\n\n%d\n%d\n\n\n\n\n" , random1 , random2 );
        


    }


}
