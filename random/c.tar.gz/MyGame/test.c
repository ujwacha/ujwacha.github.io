#include <stdio.h>
#include <stdlib.h>
#include <time.h>



int randomNumber4Me(void){
	
	 // passing time on the function 
	int number = rand(); // returning the time and checking  the remainder by 6
	return number ;
}


int main(){
    for (int i = 0 ; i < 10 ; i++){
		
		int random = randomNumber4Me();
		printf("\nThe random Number is : >> %i\n" , random);


	}
}

