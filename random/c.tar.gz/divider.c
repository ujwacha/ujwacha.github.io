#include <stdio.h>

float divider(float x , float y , float z){
	return ((x/y)/z);
}
int main(){
	float a , b , c ;
	printf("Number >>>>> ");
	scanf("%f",&a);
	printf("Number >>>>> ");
	scanf("%f",&b);
	printf("Number >>>>> ");
	scanf("%f",&c);
	printf("divided value >>>>> %f \n\n\n\n",divider(a,b,c));
	return 0;
}
