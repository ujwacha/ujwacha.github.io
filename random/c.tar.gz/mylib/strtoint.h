int bettergive(char a){
  return (((int)a) - (int)'0') ; // because ASCII value of 0 is 48 , 1 is 49 and it goes so on  
}

int strtoint(char str[]){
  int ret = 0 ;
  for(int i = 0 ; str[i]!='\0' ; i++){
    ret = ret*10 + bettergive(str[i]) ;
  }
  return ret ; 

}



/* int give(char a){ */
/*   switch (a){ */
/*   case '1' : */
/*     return 1 ; */
/*     break; */
/*   case '2' : */
/*     return 2 ; */
/*     break; */
/*   case '3' : */
/*     return 3 ; */
/*     break; */
/*   case '4' : */
/*     return 4 ; */
/*     break; */
/*   case '5' : */
/*     return 5 ; */
/*     break; */
/*   case '6' : */
/*     return 6 ; */
/*     break; */
/*   case '7' : */
/*     return 7 ; */
/*     break; */
/*   case '8' : */
/*     return 8 ; */
/*     break; */
/*   case '9' : */
/*     return 9 ; */
/*     break; */
/*   case '0' : */
/*     return 0 ; */
/*     break; */
 
/*   } */

/* } */

// the above function was written by me but that was no t that great , so i changed the function to bettergive because it is better


