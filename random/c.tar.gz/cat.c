#include <stdio.h>

int main(int argc , char *argv[]){
  FILE *fp ;
  char ch ;
  for(int i = 1 ; i < argc ; i++){
    fp = fopen(argv[i] , "r") ;
	while((ch = fgetc(fp)) != EOF) {
      	printf("%c", ch);

    } fclose(fp);

  }
    return 0 ;
}
