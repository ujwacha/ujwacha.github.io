#include <stdio.h>
#include <stdlib.h>

struct block {
	int num ;
	struct block *next ;
} ;

typedef struct block list ;

int allprinter(list *one){
  int num = one->num ;
  list *next = one->next ;
  printf("\n%d\n",num) ;
  
  if (next == NULL){
    return 0 ;
  }
  
  allprinter(next) ;

}

int adderLast(list *first , int a){
  list *next = first->next ;
  if (next == NULL){
    list *new = malloc(sizeof(list)) ;
    next = new ;
    next->num = a ;
    next->next = NULL ;
    return 0 ;
  }

  adderLast(next , a) ;
  
}


int main(){
  list first ;
  first.num = 1 ;
  list second ;
  second.num = 2 ;
  second.next = NULL ;
  first.next = &second ;
  //  adderLast(&first , 3) ;

  
  allprinter(&first) ;

}

