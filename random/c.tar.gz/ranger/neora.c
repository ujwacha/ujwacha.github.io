#include <stdio.h>
#include <stdlib.h>









int main(){
    FILE *fp ; // Declaring a pointer to read from a file 
    char ch[100] ;
    fp = fopen("filetoread" , "r") ;
    if (fp == NULL){return 1;}
    int NoOfItemsInArray = sizeof(ch)/sizeof(ch[0]);
    printf("%i\n\n" , NoOfItemsInArray) ;
    for(int i = 0; i < NoOfItemsInArray ; i++ ){


        if(fgetc(fp)==EOF){break ;}
        ch[i] = fgetc(fp);
    }
    printf("\n\n%s\n" , ch);
    printf("\n\nEND\n") ;\
    fclose(fp);
}