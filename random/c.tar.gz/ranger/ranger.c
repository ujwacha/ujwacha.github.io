#include <stdio.h>
#include <stdlib.h>






void marker(){        /// this function is to mark eg "/Hello   ****" this is how it will mark XD
   // putchar();    /// This unction is perfect no edits needed
   printf("It reached the maker function ! Cool \n");
    for (int i = 0 ; i < 3 ; i++ ){
        putchar('*');
    }
}



void move(char inp , int *ptr){
    char command[100] ;

    if(inp == 'w'){
        *ptr++;
	printf("Added the ptr\n");
    }if (inp == 's'){
        *ptr--;
	printf("Subtracted the ptr\n");
    }
/*******
    if (inp == 'c'){
        fgets(command , 100 , stdin);
        system(command);
    }
***********/

}





int main(){
    FILE *fp ;// to open the file 
    printf("Created File *fp pointer \n");
    int line = 0 ;      // to check the  line number , from the output ls -al
    int InLine = 0 ;    // to mark the  location of the marker
    printf("Created Vars line and InLine \n");
    //    int *InLinePtr = &InLine ; // pointer to inline so that the variable register can be accessed from anywhae 
    char ch ;       // a variable to print opt with putchar() function 
    char scan ;
    printf("Created chars ch and scan \n") ;
    
    while (1) {
	    printf("Entered the While loop\n");
	    
    system("ls -a > ~/nra/list");
    printf("sys command ls activated \n");
    fp = fopen("~/nra/list" , "r");
    printf("file opened in read mode about to enter the while loop again\n");
    while (ch = fgetc(fp) != EOF){
		printf("Sucessfully enreted the while loop \n");
		
            putchar(ch);// to output 
          
		printf("Sucessfully put the char \n");


	    if (ch == '\n'){            // to find how many lines are there 
                line ++; printf("Sucefully added the line \n");

            } 
            if (line == InLine) {       // to mark the required location 
                marker() ; printf("Sucefully added the marker");
            }


        }

	
            scan = getchar();


	move(scan , &InLine);


    }


    return 0 ;
}
