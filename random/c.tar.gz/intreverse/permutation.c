#include <stdio.h>
#include "head.h"
long unsigned int perm(int a , int b){
  long unsigned int ret1 = 1 ;
  long unsigned int ret2 = 1 ;
  for(int i = a ; i > (a-b) ; i--){
    ret1*= i ;
  }

  /* for(int i = b; i > 1; i--){ */
  /*   ret2*= i ; */
  /* } */


  return (ret1) ;
}


int main(int argc , char* argv[]){
  int k , l ;
  int remain ;
  if ( argc != 3 ) {printf("no of arguments do not match !\nthis program works like this : C(<arg1> , <arg2>)\n"); return 1 ;}

  k = strtoint(argv[1]) ;
  l = strtoint(argv[2]) ;
  printf("P(%d , %d) = %d" , k , l , perm(k,l)) ;
  
  putchar('\n') ;
  return 0 ;
}
