#include <stdio.h>
#include "head.h"
int main(int argc , char* argv[]){
  int k , l ;
  l = 0 ;
  int remain ;
  for(int i = 1 ; i < argc ; i++){
    k = strtoint(argv[i]) ;
    while (k != 0){
      remain = k % 10 ;
      l = l*10 + remain ;
      k = k / 10 ;
    
    }
    printf("arg%d\t%d\t" , i , l) ;
    l = 0 ;
  }
  putchar('\n') ;
}
