/* this is my cool brainfck interpretor , have fun  */
#include <stdio.h>

int main(i)
