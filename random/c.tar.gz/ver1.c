#include <stdio.h>
#include <stdlib.h>

struct block {
	int num ;
	struct block *next ;
} ;

void cat(struct block *inp, int numb){
	while (inp->next != NULL) {
		inp = inp->next ;
		putchar('*');		
	}
	
	struct block *dummy = malloc(sizeof(struct block)) ;
	if (dummy = NULL){ return ; }
	inp->next = dummy ;
	inp->next->num = numb ;

}

void allprinter (struct block *imp){

	do{
	
		printf("%i",imp->num) ;
		imp = imp->next ;


	}while(imp->next != NULL); 
}

int main() {

	struct block head ;
	struct block *ptrhead = &head ;
	head.num = 5 ;
	ptrhead->next = NULL ;	
/******	cat(ptrhead , 6);
	cat(ptrhead , 7);
	cat(ptrhead , 8);
	allprinter(ptrhead);
**********/
}
