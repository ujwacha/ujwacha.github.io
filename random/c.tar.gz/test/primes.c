#include <stdio.h>

int is_prime(int p){
	int count ;
	for (int i = 2 ; i < p ; i ++ ){
		if(p % i == 0){
			return 0 ;
		}
	}
	return 1 ;
}
int main() {
	for(int i = 1 ; i <=10000 ; i++){
		if(is_prime(i)){
			printf("\n%i\n",i);
		}
	}
}
