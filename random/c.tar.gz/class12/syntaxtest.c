#include <stdio.h>


int main() 
{
// we are gonna thest the syntax grammr of do loop in the gcc compiler
  int iodine = 45 ;


  if(iodine == 45 ){
    printf("this is it , it is fucking 45");
  }
	int i = 0 ;

	do {

		i++ ;
		printf("%i\n",i) ;

	}

	while (i <= 100) ;
       
// with this test , it was found that there must not be anything except "while" right after the "do" block
}
