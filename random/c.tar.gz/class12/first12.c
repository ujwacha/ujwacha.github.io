#include <stdio.h>
#include <string.h>
// to copy string , uncomment with M-x uncomment-region 


/* int main(){ */
/*   char str1[44] ; */
/*   printf("enter a string (stored in str1) >> "); */
/*   /\* scanf("%s",&str1); *\/ */
/*   gets(str1) ; */
/*   char str2[strlen(str1)] ; */
/*   for (int i = 0 ; str1[i] != '\0' ; i++){ */
/*     str2[i] = str1[i] ; */
/*   } */
/*   /\* printf("str2 is %s\n", str2) ; *\/ */
/*   printf("str2 is ") ; */
/*   puts(str2); */
/*   putchar('\n'); */
/*   return 0 ; */
/* } */

