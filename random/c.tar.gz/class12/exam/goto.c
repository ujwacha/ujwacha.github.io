#include <stdio.h>

int main() {
	int i = 0 ;
	label1:
	printf("%i",i)
	; i++ ;
label2:
	printf("let's see if this crap executes \n\n  "); ;
	goto label1;
	return 0 ;
}
