#include <stdio.h>

/********
 *objective:
 *print a mountain 
 *requiremet : odd number must be inputed 
 *
 *      f
 *     fff
 *    fffff 
 *
 * ***********/
void printer(int i , char j ){
	for (int l = 0 ; l < i ; l++){
		putchar(j);
	}

}

int main(){
   	int columns ; 
	do {
		printf("input a number >> ");
		scanf("%i",&columns);
	}while(0) ;//while(columns % 2 == 0) ;
	
	int base = (2*columns)-1 ;
	int fspace = ( (int) base/2 ) - 1 ;
	
	for(int i = 1 ; i < fspace ; i ++ ){
		int cspaces = fspace - i + 1 ;
		int odd = (2*i) -1 ;
		printer(cspaces , ' ') ;
		printer(odd , '*') ;
		putchar('\n');
	}
	

}
