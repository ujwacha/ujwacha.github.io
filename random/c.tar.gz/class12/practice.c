#include <stdio.h>

int main(){
  char str1[30] = "Hello" ;
  char str2[30] ;
  

  printf("%c\n" , str1[1]);
  for(int i = 0 ; i < sizeof(str1) ; i++){
    str2[i] = /* (char) */ str1[i];
    if (str1[i] == '\0') {break ;}
  }
  printf("str1 is %s\nand str2 is %s\n" , str1 , str2) ;
  return 0 ;
  
 
}
