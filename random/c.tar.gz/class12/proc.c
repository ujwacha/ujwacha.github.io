#include <stdio.h>

int main(){
	printf("%s","Hello World\n");

}
