#include <stdio.h>
void printer() ;
void triangle() ;
int main() {

	for(int i=1 ; i <= 3 ; i++){
	
		printer(i);
	}

	for(int i=1 ; i <= 4 ; i++){
	
		printer(i);
	}



	return 0 ;
}

void printer(int a) {
	int i ;
	for(i=0 ; i < a ; i++){
		putchar('*');
	}
	putchar('\n');
}




