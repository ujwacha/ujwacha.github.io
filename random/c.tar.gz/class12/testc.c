#include <stdio.h> 

int main()

{

int var1, var2;
printf("Input the value of varl:");
scanf("%d", &var1);
printf("Input the value of var2: ");
scanf("%d",&var2);
if (var1 != var2) {

printf("varl is not equal to var2\n"); //Nested if else if (var1 > var2)

{

}

else

printf("varl is greater than var2\n");

printf("var2 is greater than var1\n");

}

}

else

{

printf("varl is equal to var2\n");

}

return 0;

}
