#include <stdio.h>

int
main()
{
	int age ;
	printf("age ? >> ");
	scanf("%i",&age);
	(age >= 18)? (printf("you can vote \n")) : (printf("you can't vote \n")) ;

}

