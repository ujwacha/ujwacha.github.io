#include <stdio.h>
#include <stdlib.h>

// this will be the structure of the c linked list . it will store int

struct block {
  int num ;
  struct block *next;
  
} ;


int adder(){}


int main(){
  // head
  struct block head ;
  struct block *headptr = &head ;
  head.num = 5;
  head.next = NULL ;

  /* struct block one ; */
  /* one.num = 6 ; */
  /* head.next = &one ; */

  /* printf("" , head.num); */
  printf("%i" , head.next);
  
  

}
