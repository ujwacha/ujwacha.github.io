//***My awsome TicTacToe MULTIPLAYER offline**//
//*Author - Acharya Ujwol <AU>*//
/***************
 * Indes of the game 
 * 0|1|2
 *
 * 3|4|5
 *
 * 6|7|8
 *
 * This is the index , the moves will be kept on the places in the board  according to the 
 * index of numbers shown above
 * Have fun XDDDDDDDDDDDDDDDDDD :-)
 *
 * ******************/

/******** Header files ***********/
#include <stdio.h> // for printf() and scanf() functions //
#include <stdlib.h> // for exit() function //


//  including Headers is over
/*********** The Data Array keeps track of everything happening on the board , 
as int is a 16 bit variable ,
the size of the array is 9 times 16 bits which
is equal to 18 bytes *************/

int Data[9] = {32,32,32,32,32,32,32,32,32}; // 32 in ascii represents ' '

void output(){ // This function outputs stuff on the terminal
    printf("_______________________________________________\n") ;
    printf("%c|%c|%c\n%c|%c|%c\n%c|%c|%c\n",Data[0],Data[1],Data[2],Data[3],Data[4],Data[5],Data[6],Data[7],Data[8]);         
    printf("_______________________________________________\n") ;
}
void Checker(){ // worst part
/******This is what you call a nested if  statements and it's boring
        these boring things are just the rules of the game TicTacToe 
        This is the most boring part of the program , it uses AND gate to make sure that the 
        conditions are true . i mean the rule , checks if the rules are fulfilled to win the game ,
        if not the function will ask for a new move , else , the program terminates after 
        decelearing the winner  ********/    

    if(Data[0]==Data[1] && Data[1] == Data[2] && Data[2]!= 32){ //1
        output();
        printf("%c is the winner \n\nThe game is going to exit\n",Data[2]);
        exit(0);
    }else if(Data[3]==Data[4] && Data[4] == Data[5] && Data[5]!= 32){ //2
        output();
        printf("%c is the winner \n\nThe game is going to exit\n",Data[5]);
        exit(0);
    }else if(Data[6]==Data[7] && Data[7] == Data[8] && Data[8]!= 32){ //3
        output();
        printf("%c is the winner \n\nThe game is going to exit\n",Data[8]);
        exit(0);
    }else if(Data[0]==Data[3] && Data[3] == Data[6] && Data[6]!= 32){ //4
        output();
        printf("%c is the winner \n\nThe game is going to exit\n",Data[6]);
        exit(0);
    }else if(Data[1]==Data[4] && Data[4] == Data[7] && Data[7]!= 32){ //5
        output();
        printf("%c is the winner \n\nThe game is going to exit\n",Data[7]);
        exit(0);
    }else if(Data[2]==Data[5] && Data[5] == Data[8] && Data[8]!= 32){ //6
        output();
        printf("%c is the winner \n\nThe game is going to exit\n",Data[8]);
        exit(0);
    }else if(Data[1]==Data[4] && Data[4] == Data[8] && Data[8]!= 32){ //7
        output();
        printf("%c is the winner \n\nThe game is going to exit\n",Data[8]);
        exit(0);
    }else if(Data[2]==Data[4] && Data[4] == Data[6] && Data[6]!= 32){ //8
        output();
        printf("%c is the winner \n\nThe game is going to exit\n",Data[6]);
        exit(0);
    }else if(Data[0]==Data[4] && Data[4] == Data[8] && Data[8]!= 32){ //8
        output();
        printf("%c is the winner \n\nThe game is going to exit\n",Data[8]);
        exit(0);
    }else {
        printf("Next Turn\n\n") ;
    }

}

int main(){ ////// Main Function
    int input;
    
    int turn = 0 ;
    while (1){
        output(); // here , we output the boarde in the terminal ///
        printf("\nWhere do you want to put >> "); // we ask for an input ///
        scanf("%i",&input);
        if (Data[input] == 32){ // checks if a piece is already there ///
        
            if ((turn % 2 )== 0 ){ // checks the turn by using the remainder algorithm ,
	      //there can only be  2 answers ie 0 or 1 ////
                Data[input] = 79; // 79 is ASCII represents 'O' ///
                turn++; // increments the turn , ie it gives turn to another player ///
            }else{
                Data[input] = 88; // 88 in ASCII represents 'X' //
                turn++; // increments the turn , ie it gives turn to another player ////
            }
        }else {
            printf(" \n\nA move has already been made there\n\n");
        }

        Checker(); // checks if somebody has won ....
	//if somebody has won exit(0) function loads up terminating the program ////
        // check the Checker() function ///

    }

}
