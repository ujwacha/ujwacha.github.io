#include <stdio.h>
int main(){

	
	printf("hello");
	printf("hello");
	printf("hello");
	printf("hello\n\n");
	printf("%i\n\n",'X');
	return 0;

} 
