#include <stdio.h>
//#include <stdlib.h>
//#include <math.h>
#include "test.c"
//Main Function 
int main(){
	char x[15] ;
	int times ; 
	printf("input the character to multiply ");
	scanf("%s",x);
	printf("\n\n\ninput : how many times do you want to multiply ");
	scanf("%i",&times);
	multiplyer(x , times);
	return 0 ;
}
