//#include <stdio.h>
void multiplyer(char x[] , int y){
	for (int i = 0 ; i < y ; i++){
		printf("%s",x);
	}
	printf("\n\n");
}


