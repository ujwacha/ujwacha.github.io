#include <stdio.h>
int main(void){
	int x ;
	printf("count upto >>>> ");
	scanf("%i",&x);
	for(int i = 0 ; i <= x ; i++){
		printf("%i\n",i);

	}
	return 0 ;
}
