#include<stdio.h>
#include<time.h>
#include<stdlib.h>

int randomNumber4Me(void){
  
  srand(time(NULL));  // passing time on the function 
  int number = rand(); // returning the time and checking  the remainder by 6
	
}
int main(){
  int count  = 1;
  int correct = (randomNumber4Me() % 6) ;
  // generating a random nimber in the range of 0 - 5
  int input ;
  //decelaring variables
  while (1) {
    //this says the program to loop FOREVER hello
    printf("\n\n\n\n\nguess a number fron 0 to 5   ") ;
       // what the end user sees
    scanf("%d",&input);
    // taking input fron the console and assigning the value to the variable input
    if (correct == input){
      //checking if the inputed value is equal to the correct value 
      printf("\n!!!!YOU WON!!!!\n");
      // the player wins as he guessed the correct number
      break;	
    }else {
      printf("\ntoo bad , Wrong number :(\n");
      // the player did not guess the right number
    }
    count ++ ;
  }
  printf("\n\nyou attempted %d times :o \n\n\n",count);
  printf("Thank you for playing the Game\n\n\n\n\n");
  return 0 ;
  // the program exits
}
