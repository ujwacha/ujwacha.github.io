#include <stdio.h>
void GiveValue(int *x){
    *x = 65;

}
int main(){
    int Number;
    int *Number_Pointer;
    Number_Pointer = &Number;
    GiveValue(Number_Pointer);
    putchar(Number);
    printf("\n%c\n\n",Number);
}
